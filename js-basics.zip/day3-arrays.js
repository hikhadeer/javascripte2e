


// Arrays

// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
// console.log('arr: ', arr);

// // Adding Elements in array

// // Adding at the end
// arr.push(6);
// arr.push(7);
// arr.push(8);
// arr.push(9);
// console.log('arr: ', arr);
// // Adding at the beginning
// arr.unshift(0);
// console.log('arr: ', arr);
// // Addinig somewhere in the middle
// arr.splice(2, 0, -1, -2, -3, 'a');
// console.log('arr: ', arr);

// Removing Elements in Array

// End
// const deletedItem = arr.pop();
// console.log('deletedItem: ', deletedItem);
// console.log('arr: ', arr);
// //Beginning
// const start = arr.shift();
// console.log('start: ', start);
// console.log('arr: ', arr);
// //Middle
// arr.splice(5, 2);
// console.log('arr: ', arr);

// Finding Elements

// const element = arr.indexOf(0);
// console.log('element: ', element);

// const element1 = arr.indexOf(100) > 0 ? console.log('Element is Present!') : console.log('Element is Not Present!');
// if(element1 != -1)
//     console.log('Element is Present!');

// if(arr.includes(9)){
//     console.log('arr.includes(9): ', arr.includes(9));
//     console.log('Element is Present!');
// }

// const modifiedArray = arr.splice(0);
// console.log('modifiedArray: ', modifiedArray);

// const clonedArray = [...arr];
// console.log('clonedArray: ', clonedArray);

// const fatArrow = () => console.log('Hello World! Am Arrow Function!')

// fatArrow();

let objArray = [
    {id:1, name:'john'},
    {id:2, name:'krishna'},
    {id:3, name:'gayathri'},
    {id:4, name:'subbu'},
    {id:5, name:'khadeer'},
]


// console.log('objArray: ', objArray);

// objArray.push({id:6, name:'khan'});
// console.log('objArray: ', objArray);

// objArray.indexOf(1);
// console.log('objArray.indexOf(1): ', objArray.indexOf(1));

// // objArray.includes({id:3, name:'gayathri'});
// console.log(`objArray.includes({id:3, name:'gayathri'});: `, objArray.includes({id:3, name:'gayathri'}));

// Empty an array

// delete objArray;
// console.log('objArray: ', objArray);

// objArray = [];
// // objArray[1] = {id:12, name:'krishna12'};
// let copyArray = objArray;

// // console.log('objArray: ', objArray);
// console.log('copyArray: ', copyArray);

